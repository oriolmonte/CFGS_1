﻿namespace A2Vehicles
{
    partial class frmUpdateStatistics
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            txtIUsed = new TextBox();
            txtINew = new TextBox();
            txtNew = new TextBox();
            txtUsed = new TextBox();
            lblMonthU = new Label();
            lblYearU = new Label();
            btnEdit = new Button();
            lblIncomeUsed = new Label();
            lblIncomeNew = new Label();
            lblUsed = new Label();
            lblNew = new Label();
            lblMonth = new Label();
            lblYear = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(txtIUsed);
            groupBox1.Controls.Add(txtINew);
            groupBox1.Controls.Add(txtNew);
            groupBox1.Controls.Add(txtUsed);
            groupBox1.Controls.Add(lblMonthU);
            groupBox1.Controls.Add(lblYearU);
            groupBox1.Controls.Add(btnEdit);
            groupBox1.Controls.Add(lblIncomeUsed);
            groupBox1.Controls.Add(lblIncomeNew);
            groupBox1.Controls.Add(lblUsed);
            groupBox1.Controls.Add(lblNew);
            groupBox1.Controls.Add(lblMonth);
            groupBox1.Controls.Add(lblYear);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(259, 560);
            groupBox1.TabIndex = 5;
            groupBox1.TabStop = false;
            // 
            // txtIUsed
            // 
            txtIUsed.Location = new Point(76, 348);
            txtIUsed.Name = "txtIUsed";
            txtIUsed.Size = new Size(111, 23);
            txtIUsed.TabIndex = 20;
            // 
            // txtINew
            // 
            txtINew.Location = new Point(76, 280);
            txtINew.Name = "txtINew";
            txtINew.Size = new Size(111, 23);
            txtINew.TabIndex = 19;
            // 
            // txtNew
            // 
            txtNew.Location = new Point(76, 219);
            txtNew.Name = "txtNew";
            txtNew.Size = new Size(111, 23);
            txtNew.TabIndex = 18;
            // 
            // txtUsed
            // 
            txtUsed.Location = new Point(76, 160);
            txtUsed.Name = "txtUsed";
            txtUsed.Size = new Size(111, 23);
            txtUsed.TabIndex = 6;
            // 
            // lblMonthU
            // 
            lblMonthU.AutoSize = true;
            lblMonthU.Location = new Point(67, 79);
            lblMonthU.Name = "lblMonthU";
            lblMonthU.Size = new Size(38, 15);
            lblMonthU.TabIndex = 17;
            lblMonthU.Text = "label8";
            // 
            // lblYearU
            // 
            lblYearU.AutoSize = true;
            lblYearU.Location = new Point(63, 32);
            lblYearU.Name = "lblYearU";
            lblYearU.Size = new Size(38, 15);
            lblYearU.TabIndex = 6;
            lblYearU.Text = "label7";
            // 
            // btnEdit
            // 
            btnEdit.Location = new Point(17, 418);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(236, 99);
            btnEdit.TabIndex = 16;
            btnEdit.Text = "Edit register";
            btnEdit.UseVisualStyleBackColor = true;
            btnEdit.Click += btnEdit_Click;
            // 
            // lblIncomeUsed
            // 
            lblIncomeUsed.AutoSize = true;
            lblIncomeUsed.Location = new Point(21, 356);
            lblIncomeUsed.Name = "lblIncomeUsed";
            lblIncomeUsed.Size = new Size(0, 15);
            lblIncomeUsed.TabIndex = 15;
            lblIncomeUsed.TextAlign = ContentAlignment.TopRight;
            // 
            // lblIncomeNew
            // 
            lblIncomeNew.AutoSize = true;
            lblIncomeNew.Location = new Point(21, 304);
            lblIncomeNew.Name = "lblIncomeNew";
            lblIncomeNew.Size = new Size(0, 15);
            lblIncomeNew.TabIndex = 14;
            // 
            // lblUsed
            // 
            lblUsed.AutoSize = true;
            lblUsed.Location = new Point(204, 253);
            lblUsed.Name = "lblUsed";
            lblUsed.Size = new Size(0, 15);
            lblUsed.TabIndex = 13;
            lblUsed.TextAlign = ContentAlignment.TopRight;
            // 
            // lblNew
            // 
            lblNew.AutoSize = true;
            lblNew.Location = new Point(21, 253);
            lblNew.Name = "lblNew";
            lblNew.Size = new Size(0, 15);
            lblNew.TabIndex = 12;
            // 
            // lblMonth
            // 
            lblMonth.AutoSize = true;
            lblMonth.Location = new Point(204, 201);
            lblMonth.Name = "lblMonth";
            lblMonth.Size = new Size(0, 15);
            lblMonth.TabIndex = 11;
            lblMonth.TextAlign = ContentAlignment.TopRight;
            // 
            // lblYear
            // 
            lblYear.AutoSize = true;
            lblYear.Location = new Point(25, 201);
            lblYear.Name = "lblYear";
            lblYear.Size = new Size(0, 15);
            lblYear.TabIndex = 10;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label6.Location = new Point(88, 319);
            label6.Name = "label6";
            label6.Size = new Size(83, 15);
            label6.TabIndex = 9;
            label6.Text = "Income: Used";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label5.Location = new Point(88, 253);
            label5.Name = "label5";
            label5.Size = new Size(81, 15);
            label5.TabIndex = 8;
            label5.Text = "Income: New";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label4.Location = new Point(111, 142);
            label4.Name = "label4";
            label4.Size = new Size(35, 15);
            label4.TabIndex = 7;
            label4.Text = "Used";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label3.Location = new Point(111, 201);
            label3.Name = "label3";
            label3.Size = new Size(33, 15);
            label3.TabIndex = 6;
            label3.Text = "New";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label2.Location = new Point(17, 79);
            label2.Name = "label2";
            label2.Size = new Size(44, 15);
            label2.TabIndex = 5;
            label2.Text = "Month";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label1.Location = new Point(17, 32);
            label1.Name = "label1";
            label1.Size = new Size(31, 15);
            label1.TabIndex = 4;
            label1.Text = "Year";
            // 
            // frmUpdateStatistics
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(284, 583);
            Controls.Add(groupBox1);
            Name = "frmUpdateStatistics";
            Text = "frmUpdateStatistics";
            Load += frmUpdateStatistics_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private TextBox txtINew;
        private TextBox txtNew;
        private TextBox txtUsed;
        private Label lblMonthU;
        private Label lblYearU;
        private Button btnEdit;
        private Label lblIncomeUsed;
        private Label lblIncomeNew;
        private Label lblUsed;
        private Label lblNew;
        private Label lblMonth;
        private Label lblYear;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtIUsed;
    }
}